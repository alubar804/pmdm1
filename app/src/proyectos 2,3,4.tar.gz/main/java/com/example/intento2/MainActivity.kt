package com.example.intento2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
        val nro1 = et1.text.toString().toInt()
        val nro2 = et2.text.toString().toInt()
        val suma = nro1 + nro2
        println("El resultado de la suma es:")
        println(suma.toString())
        }
        println("Proyecto3:")
        //Definir una variable inmutable con el valor 50 que representa el lado de un
        //cuadrado, en otras dos variables inmutables almacenar la superficie y el
        //perímetro del cuadrado.
        //Mostrar la superficie y el perímetro por la Consola.
        val pr3Lado = 50
        val pr3per=pr3Lado*4
        val pr3Super=pr3Lado*pr3Lado
        println("El lado es: "+pr3Lado.toString())
        println("El perimetro es igual a la suma de los lados:"+pr3per.toString())
        println("La superficie del cuadrado es igual al lado multiplicado por si mismo"+pr3Super.toString())

        println("---------------------")
        println("Proyecto4:")
        //Definir tres variables inmutables y cargar por asignación los pesos de tres
        //personas con valores Float. Calcular el promedio de pesos de las
        //personas y mostrarlo.
        val pr4peso1 = 123.4f
        val pr4peso2 = 56.7f
        val pr4peso3 = 89.1f
        val media =(pr4peso1+pr4peso2+pr4peso3)/3
        println("El promedio es: "+media.toString())
    }
}